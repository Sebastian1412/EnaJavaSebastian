-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-06-2020 a las 01:37:37
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `requerimiento`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignacion`
--

CREATE TABLE `asignacion` (
  `id_asignacion` int(11) NOT NULL,
  `asignacion` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `asignacion`
--

INSERT INTO `asignacion` (`id_asignacion`, `asignacion`) VALUES
(1, 'Asistente'),
(2, 'Tecnico'),
(3, 'Supervisor'),
(4, 'Encargado'),
(5, 'Direccion');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE `departamento` (
  `id_departamento` int(11) NOT NULL,
  `departamento` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `departamento`
--

INSERT INTO `departamento` (`id_departamento`, `departamento`) VALUES
(1, 'Area TI'),
(2, 'Desarrollo'),
(3, 'Marketing'),
(4, 'Recursos Humanos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `encargado`
--

CREATE TABLE `encargado` (
  `id_encargado` int(11) NOT NULL,
  `encargado` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `encargado`
--

INSERT INTO `encargado` (`id_encargado`, `encargado`) VALUES
(1, 'Jose Antonio Macias'),
(2, 'Christina Hernandez'),
(3, 'Laura Torrez'),
(4, 'Mario Pardo'),
(5, 'Pedro Fernandez'),
(7, 'Urbano Palomino'),
(9, 'Pascual Camacho'),
(10, 'Eric Sandoval'),
(11, 'Raimundo Linares'),
(12, 'Jacobo Duque'),
(13, 'Arnoldo Pavez'),
(14, 'Renato Antilef'),
(16, 'Israel Rebollo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gerencia`
--

CREATE TABLE `gerencia` (
  `id_gerencia` int(11) NOT NULL,
  `gerencia` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `gerencia`
--

INSERT INTO `gerencia` (`id_gerencia`, `gerencia`) VALUES
(1, 'CEO'),
(2, 'Asistente del Gerente\r\n'),
(3, 'Supervisor Abastecimiento'),
(4, 'Encargado de Ventas'),
(5, 'Jefe de Desarrollo'),
(6, 'Supervisor Desarrollo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `requerimientos`
--

CREATE TABLE `requerimientos` (
  `ID_Requerimiento` int(11) NOT NULL,
  `Detalle` varchar(1000) DEFAULT NULL,
  `Gerencia` varchar(100) DEFAULT NULL,
  `Asignacion` varchar(100) DEFAULT NULL,
  `Encargado` varchar(100) DEFAULT NULL,
  `Departamento` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `requerimientos`
--

INSERT INTO `requerimientos` (`ID_Requerimiento`, `Detalle`, `Gerencia`, `Asignacion`, `Encargado`, `Departamento`) VALUES
(1, 'probando requerimiento 19:27', 'Jefe de Desarrollo', 'Tecnico', 'Rut DÃ­az', 'Area TI'),
(5, 'Reparar impresora del departamento...', 'CEO', 'Asistente', 'Jose Antonio Macias', 'Area TI'),
(6, 'Reparar alertas del programa requerimientos', 'Asistente del Gerente', 'Tecnico', 'Rut DÃ­az', 'Desarrollo'),
(7, 'Reparar PC del salon ', 'Jefe de Desarrollo', 'Tecnico', 'Mario Pardo', 'Area TI'),
(8, 'reparar mesas del sector marketing', 'Supervisor Abastecimiento', 'Encargado', 'Jose Antonio Macias', 'Marketing'),
(9, 'comprar nuevos muebles', 'Encargado de Ventas', 'Direccion', 'Renato Antilef', 'Area TI'),
(10, 'Gestionar encargos de resmas', 'Supervisor Abastecimiento', 'Direccion', 'Mario Pardo', 'Recursos Humanos'),
(11, 'Gestionar encargos de resmas', 'Supervisor Abastecimiento', 'Direccion', 'Mario Pardo', 'Recursos Humanos'),
(12, 'comprar cables para los equipos ', 'Encargado de Ventas', 'Supervisor', 'Jose Antonio Macias', 'Recursos Humanos'),
(13, 'comprar nuevos lapices ', 'CEO', 'Encargado', 'Mario Pardo', 'Marketing'),
(14, 'reparar maquina de cafe', 'Encargado de Ventas', 'Supervisor', 'Laura Torrez', 'Area TI'),
(15, 'reparar maquina de dulces', 'Asistente del Gerente', 'Asistente', 'Christina Hernandez', 'Desarrollo'),
(16, 'encargo de tintas para impresora', 'Encargado de Ventas', 'Tecnico', 'Mario Pardo', 'Recursos Humanos'),
(17, 'gestionar para comprar chaquetas para los trabajadores', 'Supervisor Abastecimiento', 'Supervisor', 'Mario Pardo', 'Recursos Humanos'),
(18, 'comprar mas artÃ­culos de oficina ', 'Jefe de Desarrollo', 'Tecnico', 'Pedro Fernandez', 'Marketing'),
(19, 'gestionar licencias para office ', 'Jefe de Desarrollo', 'Encargado', 'Pedro Fernandez', 'Area TI'),
(20, 'gestionar licencias para visual estudio ', 'Jefe de Desarrollo', 'Encargado', 'Pedro Fernandez', 'Area TI'),
(21, 'gestionar higiene personal a trabajadores ', 'CEO', 'Supervisor', 'Christina Hernandez', 'Recursos Humanos'),
(22, 'gestiÃ³n de feriados', 'Encargado de Ventas', 'Tecnico', 'Pedro Fernandez', 'Marketing'),
(23, 'se requiere reparar maquina de cafe ', 'Asistente del Gerente', 'Tecnico', 'Urbano Palomino', 'Marketing'),
(24, 'comprar licencias de windows 10', 'Jefe de Desarrollo', 'Direccion', 'Urbano Palomino', 'Area TI'),
(25, 'gestionar pinturas', 'Supervisor Abastecimiento', 'Direccion', 'Israel Rebollo', 'Marketing'),
(26, 'reprar impresora de sala', 'Encargado de Ventas', 'Supervisor', 'Christina Hernandez', 'Recursos Humanos'),
(27, 'gestionar pedido de utensilios de aseo ', 'Supervisor Abastecimiento', 'Supervisor', 'Mario Pardo', 'Recursos Humanos'),
(28, 'comprar platos', 'Supervisor Desarrollo', 'Direccion', 'Israel Rebollo', 'Recursos Humanos'),
(29, 'reparaciÃ³n de estufa ', 'Jefe de Desarrollo', 'Encargado', 'Raimundo Linares', 'Marketing'),
(30, 'gestionar reparaciÃ³n de mesas', 'Encargado de Ventas', 'Supervisor', 'Pascual Camacho', 'Desarrollo'),
(31, 'gestionar reparaciÃ³n de sillas ', 'Asistente del Gerente', 'Supervisor', 'Pascual Camacho', 'Area TI'),
(32, 'gestionar reparaciÃ³n de luces ', 'Asistente del Gerente', 'Supervisor', 'Raimundo Linares', 'Desarrollo'),
(33, 'comprar colaciones ', 'CEO', 'Tecnico', 'Laura Torrez', 'Marketing'),
(34, 'gestionar control de plagas', 'Supervisor Abastecimiento', 'Encargado', 'Laura Torrez', 'Marketing'),
(35, 'gestiÃ³n para equipos nuevos ', 'Asistente del Gerente', 'Supervisor', 'Laura Torrez', 'Area TI'),
(36, 'gestionar pagos', 'Asistente del Gerente', 'Supervisor', 'Pedro Fernandez', 'Desarrollo'),
(37, 'gestionar horas de colaciÃ³n ', 'Encargado de Ventas', 'Supervisor', 'Pedro Fernandez', 'Desarrollo'),
(38, 'gestionar pagos extras', 'Encargado de Ventas', 'Supervisor', 'Mario Pardo', 'Desarrollo'),
(45, 'Llene la cafetera y compre Donas', 'Asistente del Gerente', 'Asistente', 'Urbano Palomino', 'Area TI'),
(46, 'Revise los nuevos curriculums que llegaron en la maÃ±ana', 'Jefe de Desarrollo', 'Encargado', 'Laura Torrez', 'Recursos Humanos'),
(47, 'Instale nuevo Software a las computadoras', 'Jefe de Desarrollo', 'Tecnico', 'Mario Pardo', 'Desarrollo'),
(48, 'Presente la nueva idea para el producto ', 'Supervisor Desarrollo', 'Asistente', 'Jose Antonio Macias', 'Desarrollo'),
(49, 'Pida la nueva pancarta promocional del nuevo producto ', 'Encargado de Ventas', 'Encargado', 'Pascual Camacho', 'Marketing'),
(50, 'Tome el dÃ­a libre', 'CEO', 'Direccion', 'Christina Hernandez', 'Desarrollo'),
(51, 'Busque en la bodega Toner para la impresora ', 'CEO', 'Asistente', 'Israel Rebollo', 'Area TI'),
(52, 'Instale el nuevo Software para las impresoras', 'CEO', 'Tecnico', 'Arnoldo Pavez', 'Area TI'),
(53, 'Termine el informe de desempeÃ±o del tÃ©cnico de el Area TI', 'CEO', 'Supervisor', 'Laura Torrez', 'Area TI'),
(54, 'Consulte al tecnico cuanto le falta', 'CEO', 'Encargado', 'Renato Antilef', 'Area TI'),
(55, 'Esta con licencia medica por estres ', 'CEO', 'Direccion', 'Renato Antilef', 'Area TI'),
(56, 'Ingrese la contaseÃ±a del Computador principal  ', 'CEO', 'Asistente', 'Eric Sandoval', 'Desarrollo'),
(57, 'Entregue el Software al tecnico  ', 'CEO', 'Tecnico', 'Israel Rebollo', 'Desarrollo'),
(58, 'Tomo un dia libre, era el partido de baseball de su hijo', 'CEO', 'Supervisor', 'Pascual Camacho', 'Desarrollo'),
(59, 'Llame al tecnico se les quedaron las herramientas', 'CEO', 'Encargado', 'Arnoldo Pavez', 'Desarrollo'),
(60, 'Informe al CEO que el trabajo ya esta terminado', 'CEO', 'Direccion', 'Christina Hernandez', 'Desarrollo'),
(61, 'Reenvie  la imagen promocional del producto por correo ', 'CEO', 'Asistente', 'Mario Pardo', 'Marketing'),
(62, 'Entrege la colacion al tecnico ', 'CEO', 'Direccion', 'Renato Antilef', 'Marketing'),
(63, 'Contrate un tecnico para reparar la Impresora ', 'CEO', 'Asistente', 'Laura Torrez', 'Recursos Humanos'),
(64, 'Lleve el curricul al CEO para poder contratar al tecnico', 'CEO', 'Tecnico', 'Israel Rebollo', 'Recursos Humanos'),
(65, 'Vea que los trabajadores lleguen a la hora ', 'CEO', 'Direccion', 'Arnoldo Pavez', 'Recursos Humanos'),
(66, 'Borre el counter strike que el asistente instalo en la computadora ', 'Asistente del Gerente', 'Tecnico', 'Renato Antilef', 'Area TI'),
(67, 'Firme la entrega del nuevo producto', 'Asistente del Gerente', 'Direccion', 'Israel Rebollo', 'Area TI'),
(68, 'Terminar el proyecto antes del viernes', 'Asistente del Gerente', 'Supervisor', 'Arnoldo Pavez', 'Desarrollo'),
(69, 'Viernes 10:00 am junta en la oficina 444', 'Asistente del Gerente', 'Encargado', 'Renato Antilef', 'Desarrollo'),
(70, 'MaÃ±ana 10 am junta oficina 22', 'Asistente del Gerente', 'Asistente', 'Urbano Palomino', 'Marketing'),
(71, 'Prepare el proyector para las junta antes de las 10 AM', 'Asistente del Gerente', 'Tecnico', 'Israel Rebollo', 'Marketing'),
(72, 'Presentese  en la oficina del Asistente del gerente despues de la junta ', 'Asistente del Gerente', 'Supervisor', 'Arnoldo Pavez', 'Marketing'),
(73, 'Informe a su equipo de trabajo de la nueva modalidad de envio de archivos ', 'Asistente del Gerente', 'Encargado', 'Pascual Camacho', 'Marketing'),
(74, 'Entrege el informe de requerimientos que se le pidio el Lunes', 'Asistente del Gerente', 'Direccion', 'Christina Hernandez', 'Marketing'),
(75, 'Informe el desempeÃ±o de su equipo de trabajo', 'Asistente del Gerente', 'Asistente', 'Pascual Camacho', 'Recursos Humanos'),
(76, 'Busque en la sala de servidores si esta la carpeta RRDATA', 'Asistente del Gerente', 'Tecnico', 'Renato Antilef', 'Recursos Humanos'),
(77, 'Ingrese el Requerimiento del viernes ', 'Asistente del Gerente', 'Supervisor', 'Arnoldo Pavez', 'Recursos Humanos'),
(78, 'Rellene el Requerimiento v3.e', 'Asistente del Gerente', 'Encargado', 'Jacobo Duque', 'Recursos Humanos'),
(79, 'Termine el  cerrarR.java', 'Asistente del Gerente', 'Direccion', 'Pedro Fernandez', 'Recursos Humanos'),
(80, 'Pida pilas para el control la ta tv del Casino ', 'Supervisor Abastecimiento', 'Asistente', 'Jose Antonio Macias', 'Area TI'),
(81, 'La maquina de dulces se quedo sin M&M', 'Supervisor Abastecimiento', 'Tecnico', 'Arnoldo Pavez', 'Area TI'),
(82, 'Terminar el INr.java', 'Supervisor Abastecimiento', 'Supervisor', 'Laura Torrez', 'Area TI'),
(83, 'Sacar la Rata del lavadero', 'Supervisor Abastecimiento', 'Encargado', 'Mario Pardo', 'Area TI'),
(84, 'Sacar el cambio en las maquinas de dulces ', 'Supervisor Abastecimiento', 'Tecnico', 'Renato Antilef', 'Desarrollo'),
(85, 'Contar el cambio y enviar a Recursos humanos', 'Supervisor Abastecimiento', 'Supervisor', 'Raimundo Linares', 'Desarrollo'),
(86, 'Desempacar la caja de mercaderia ', 'Supervisor Abastecimiento', 'Encargado', 'Eric Sandoval', 'Desarrollo'),
(87, 'Cerrar la puerta de la bodega con llave', 'Supervisor Abastecimiento', 'Direccion', 'Renato Antilef', 'Desarrollo'),
(88, 'Cambiar las pegatinas de la Maquina', 'Supervisor Abastecimiento', 'Asistente', 'Israel Rebollo', 'Marketing'),
(89, 'Ingresar los nuevos precios', 'Supervisor Abastecimiento', 'Tecnico', 'Jose Antonio Macias', 'Marketing'),
(90, 'Decidir nuevas ofertas', 'Supervisor Abastecimiento', 'Supervisor', 'Renato Antilef', 'Marketing'),
(91, 'Aprobar el nuevo cambio de precio', 'Supervisor Abastecimiento', 'Encargado', 'Laura Torrez', 'Marketing'),
(92, 'Poner caja de reclamos junto a la maquina de cafe', 'Supervisor Abastecimiento', 'Direccion', 'Pedro Fernandez', 'Marketing'),
(93, 'Firmar documentos', 'Supervisor Abastecimiento', 'Asistente', 'Jacobo Duque', 'Recursos Humanos'),
(94, 'Impecionar la fumigacion de plagas', 'Supervisor Abastecimiento', 'Tecnico', 'Raimundo Linares', 'Recursos Humanos'),
(95, 'Pegar pegatina de fumigacion realizada ', 'Supervisor Abastecimiento', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(96, 'Aprobar Presupuesto 2020 ', 'Encargado de Ventas', 'Asistente', 'Arnoldo Pavez', 'Area TI'),
(97, 'Firmar documentos confidenciales ', 'Encargado de Ventas', 'Tecnico', 'Jacobo Duque', 'Area TI'),
(98, 'Investigar posible robo de fondos', 'Jefe de Desarrollo', 'Encargado', 'Renato Antilef', 'Area TI'),
(99, 'Cerrar Requerimientos ', 'Encargado de Ventas', 'Encargado', 'Urbano Palomino', 'Area TI'),
(100, 'Informar de posible cambio malicioso del software ', 'Encargado de Ventas', 'Asistente', 'Arnoldo Pavez', 'Desarrollo'),
(101, 'Instalar antivirus y cambiar contraseÃ±as ', 'Encargado de Ventas', 'Tecnico', 'Arnoldo Pavez', 'Desarrollo'),
(102, 'Cerrar la perta antes de salir', 'Encargado de Ventas', 'Encargado', 'Renato Antilef', 'Desarrollo'),
(103, 'Informar del nuevo software a instalar', 'Encargado de Ventas', 'Direccion', 'Arnoldo Pavez', 'Desarrollo'),
(104, 'Informar de posibles problemas con el nuevo producto', 'Encargado de Ventas', 'Asistente', 'Mario Pardo', 'Marketing'),
(105, 'Ingresar dias feriados para la prÃ³xima semana ', 'Encargado de Ventas', 'Encargado', 'Israel Rebollo', 'Marketing'),
(106, 'Cerrar Requerimientos', 'Encargado de Ventas', 'Direccion', 'Renato Antilef', 'Marketing'),
(107, 'Proxima semana cerrado por feriado irrenunciable ', 'Jefe de Desarrollo', 'Asistente', 'Arnoldo Pavez', 'Recursos Humanos'),
(108, 'Dar a conocer la lista de dias feriados de deste aÃ±o ', 'Encargado de Ventas', 'Encargado', 'Arnoldo Pavez', 'Recursos Humanos'),
(109, 'Entregar software al tecnico ', 'Jefe de Desarrollo', 'Asistente', 'Urbano Palomino', 'Area TI'),
(110, 'Entregar licencias de Windows 10 al tecnico ', 'Jefe de Desarrollo', 'Supervisor', 'Laura Torrez', 'Area TI'),
(111, 'Informar de que windows 7 se quedo sin soporte , actualizar a windows 10', 'Jefe de Desarrollo', 'Asistente', 'Pascual Camacho', 'Desarrollo'),
(112, 'Aprobar nuevas compras de productos ', 'Jefe de Desarrollo', 'Supervisor', 'Mario Pardo', 'Desarrollo'),
(113, 'Pagar el envio del producto', 'Jefe de Desarrollo', 'Encargado', 'Pedro Fernandez', 'Desarrollo'),
(114, 'Firmar cheque del envio', 'Jefe de Desarrollo', 'Direccion', 'Jacobo Duque', 'Desarrollo'),
(115, 'Informar al gerente del nuevo cambio al pruducto', 'Jefe de Desarrollo', 'Asistente', 'Jacobo Duque', 'Marketing'),
(116, 'Aprobar nuevo producto', 'Jefe de Desarrollo', 'Supervisor', 'Pascual Camacho', 'Marketing'),
(117, 'informar que el pago fue realizado', 'Asistente del Gerente', 'Direccion', 'Arnoldo Pavez', 'Marketing'),
(118, 'Cerrar la ventana del pasillo ', 'Jefe de Desarrollo', 'Tecnico', 'Raimundo Linares', 'Recursos Humanos'),
(119, 'Terminar el informe de contabilidad ', 'Jefe de Desarrollo', 'Supervisor', 'Jose Antonio Macias', 'Recursos Humanos'),
(120, 'Informar al tecnico que hay problemas con la estufa ', 'Jefe de Desarrollo', 'Direccion', 'Renato Antilef', 'Recursos Humanos'),
(121, 'Informar que el prototipo ya esta terminado', 'Supervisor Desarrollo', 'Asistente', 'Raimundo Linares', 'Area TI'),
(122, 'Instalar el software al nuevo producto ', 'Supervisor Desarrollo', 'Tecnico', 'Raimundo Linares', 'Area TI'),
(123, 'Hacer informe de desempeÃ±o del tecnico', 'Supervisor Desarrollo', 'Supervisor', 'Christina Hernandez', 'Area TI'),
(124, 'Firmar cheques de pago de sueldo', 'Supervisor Desarrollo', 'Encargado', 'Laura Torrez', 'Area TI'),
(125, 'Recibir informe de desarrollo de parte del tecnico ', 'Supervisor Desarrollo', 'Direccion', 'Mario Pardo', 'Area TI'),
(126, 'Desarrolle la idea presentada por el asistente de desarrollo ', 'Supervisor Desarrollo', 'Tecnico', 'Laura Torrez', 'Recursos Humanos'),
(127, 'Hacer informe de desempeÃ±o del tecnico a cargo', 'Supervisor Desarrollo', 'Supervisor', 'Renato Antilef', 'Desarrollo'),
(128, 'Firmar y enviar informes al CEO', 'Supervisor Desarrollo', 'Encargado', 'Pascual Camacho', 'Desarrollo'),
(129, 'Terminar proyecto InR.java', 'Supervisor Desarrollo', 'Direccion', 'Jacobo Duque', 'Desarrollo'),
(130, 'Terminar proyecto InR.java', 'Supervisor Desarrollo', 'Direccion', 'Jacobo Duque', 'Desarrollo'),
(131, 'Presentar idas propuestas por los trabajadores', 'Supervisor Desarrollo', 'Asistente', 'Urbano Palomino', 'Marketing'),
(132, 'Desarrollar las ideas presentadas por el equipo de marketing ', 'Supervisor Desarrollo', 'Tecnico', 'Christina Hernandez', 'Marketing'),
(133, 'Realizar informe de desarrollo del proyecto', 'Supervisor Desarrollo', 'Supervisor', 'Pedro Fernandez', 'Marketing'),
(134, 'Enviar proyecto al CEO', 'Supervisor Desarrollo', 'Encargado', 'Renato Antilef', 'Marketing'),
(135, 'Firmar y aprobar proyecto Requerimientos ', 'Supervisor Desarrollo', 'Direccion', 'Israel Rebollo', 'Marketing'),
(136, 'Avisar que se realizaron horas extras', 'Supervisor Desarrollo', 'Asistente', 'Mario Pardo', 'Recursos Humanos'),
(137, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Urbano Palomino', 'Recursos Humanos'),
(138, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Urbano Palomino', 'Recursos Humanos'),
(139, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Urbano Palomino', 'Recursos Humanos'),
(140, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Urbano Palomino', 'Recursos Humanos'),
(141, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Urbano Palomino', 'Recursos Humanos'),
(142, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Urbano Palomino', 'Recursos Humanos'),
(143, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Urbano Palomino', 'Recursos Humanos'),
(144, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Urbano Palomino', 'Recursos Humanos'),
(145, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Pedro Fernandez', 'Recursos Humanos'),
(146, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Urbano Palomino', 'Recursos Humanos'),
(147, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(148, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(149, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(150, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(151, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(152, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(153, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(154, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(155, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(156, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(157, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(158, 'Aprobar la realzacion de horas extras', 'Supervisor Desarrollo', 'Supervisor', 'Israel Rebollo', 'Recursos Humanos'),
(159, 'Eliminar este Requerimiento ', 'CEO', 'Asistente', 'Pedro Fernandez', 'Area TI');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `ID_Usuario` int(11) NOT NULL,
  `Nombre` varchar(100) DEFAULT NULL,
  `Contraseña` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`ID_Usuario`, `Nombre`, `Contraseña`) VALUES
(1, 'Elizabeth Pardo', '5555'),
(2, 'Ricardo Perez', '2345'),
(3, 'Hernesto Zamora', '3456'),
(4, 'Ricardo Lopez', '4567'),
(5, 'Harley Queen', '5678'),
(6, 'Thomas Wayne', '6789'),
(7, 'Rodrigo', '1996');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `asignacion`
--
ALTER TABLE `asignacion`
  ADD PRIMARY KEY (`id_asignacion`);

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`id_departamento`);

--
-- Indices de la tabla `encargado`
--
ALTER TABLE `encargado`
  ADD PRIMARY KEY (`id_encargado`);

--
-- Indices de la tabla `gerencia`
--
ALTER TABLE `gerencia`
  ADD PRIMARY KEY (`id_gerencia`);

--
-- Indices de la tabla `requerimientos`
--
ALTER TABLE `requerimientos`
  ADD PRIMARY KEY (`ID_Requerimiento`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`ID_Usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `asignacion`
--
ALTER TABLE `asignacion`
  MODIFY `id_asignacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `departamento`
--
ALTER TABLE `departamento`
  MODIFY `id_departamento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `encargado`
--
ALTER TABLE `encargado`
  MODIFY `id_encargado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `gerencia`
--
ALTER TABLE `gerencia`
  MODIFY `id_gerencia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `requerimientos`
--
ALTER TABLE `requerimientos`
  MODIFY `ID_Requerimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=160;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `ID_Usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
